public class SwitchProblem {

public static void main(String[] args) {
	switch(input)
	{
	case2: 
		System.out.println("2");
	int input = 3;
	break;
	case1:
		System.out.println("1");
	break;
	default:
		System.out.println("3");
}

}
}