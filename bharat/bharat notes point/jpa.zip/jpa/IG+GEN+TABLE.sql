create table id_gen(
gen_name varchar(60) PRIMARY KEY,
gen_val int(20)
)
