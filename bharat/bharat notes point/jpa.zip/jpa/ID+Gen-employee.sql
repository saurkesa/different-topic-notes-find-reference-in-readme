use mydb

create table employee(
id int,
name varchar(20)
)

drop table employee